/**
 * Name: Sharar Mahmood
 * Id: 0955835
 * Date: 6 Feb 2021
 * Assignment: A2
 * **/

# include <stdio.h>
# include <stdlib.h>
# include <string.h>

# define MAX_LINE_SIZE 2000
# define MAX_LINE_COUNT 100000
# define TRUE 1
# define FALSE 0

// main
void readFile(char* filePath, char** lines, int*totalLines);
void printLines(char** lines, int lineCount);



