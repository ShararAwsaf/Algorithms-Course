# include "utils.h"
# define MAX_INPUT_SIZE 50000

void createIntArrayFromStrings(int* intArray, int* intCount, char** strings, int stringCount, int intPerLine, char* separator);
void printIntArray(int* integers, int intCount);


void p11(char** lines, int lineCount);
int countInversions(int* intArray, int intCount);